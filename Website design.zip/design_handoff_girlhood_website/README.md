# Handoff: Girlhood Collective Website

## Overview
A multi-page marketing/community website for **Girlhood Collective** — a Greater Cincinnati community brand (founded 2025 by Brittany Gruber) creating events, workshops, resources, and community for women and girls. The site spans a home page, about, events, newsletter, a services/"work with me" flow, tools, UGC, partners, an intake form, and a "worth" quiz.

This bundle is the current, approved design after a palette change (raspberry → cream/blue/green/navy) and a copy change (all "east side" references replaced with "Greater Cincinnati" phrasing).

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes that show the intended look, layout, copy, and interactions. They are **not** production code to lift directly. They are authored as "Design Components" (`.dc.html`) that run in a custom preview runtime (`support.js`) and pull shared UI from a design-system bundle (`_ds_bundle.js`).

The task is to **recreate these designs in the target codebase's environment** (React, Vue, SwiftUI, native, etc.) using its established patterns, component library, and conventions. If no environment exists yet, choose the most appropriate framework for a content-driven marketing site (e.g. Next.js/Astro) and implement there. Do not ship the `.dc.html` files or the runtime directly.

## Fidelity
**High-fidelity (hifi).** These are pixel-level mockups with final colors, typography, spacing, copy, and hover interactions. Recreate the UI faithfully using the target codebase's libraries and patterns. Exact values are documented under Design Tokens below.

## Design Language
- **Voice:** warm, capable, community-first. Speaks to "you / your daughter," acts as "we." Sentence case for headlines/body; ALL-CAPS letter-spaced for eyebrows/labels; one script-font word carries the emotional beat.
- **Headline pattern (recurs everywhere):** eyebrow (tracked caps) → script/italic phrase → serif sub-line.
- **Layout:** centered single-column compositions inside a max-width page card (1180px) with a sticky white nav. Generous vertical section padding. Warm neutrals, never grey.
- **No gradients, no glassmorphism.** Texture comes from shape and color fields.

## Design Tokens

### Colors (current, post-repalette)
These are defined as CSS custom properties in each page's `:root`:
- `--gc-cream` `#FBFAF7` — warm off-white surface (brand strip, hero panels)
- `--gc-navy` / `--gc-navy-deep` / `--gc-slate` `#1B2E4A` — ink, dark bands, footer, secondary CTA
- `--gc-emerald` `#4FB286` — **primary action color** (CTAs, script accents on light, eyebrows, dividers)
- `--gc-emerald-soft` `#7FCBA6` — soft green tint
- `--gc-lavender` `#4FB286` — aliased to green (kept for backward-compat token names)
- `--gc-lavender-soft` `#BAD9F3` — **accent on dark** (eyebrows/scripts on navy panels, badges)
- `--gc-blush` `#BAD9F3` — sky-blue accent (same value as lavender-soft)
- `--gc-sage-light` `#EAF3EC` — pale green wash (hover rows, strips)
- `--gc-section` `#F4F8FB` — pale blue section wash (events section background)

Additional tokens inherited from the design-system stylesheet (`tokens/colors.css`):
- `--gc-ink` — body text on light
- `--gc-ink-muted` — secondary/muted text
- `--gc-border` — navy-tinted hairline `#DCE5EA`
- `--gc-yellow` `#F3E184`, `--gc-gold` `#D4A800` — sunshine accents (used sparingly)
- `--gc-green` `#439B75` — studio leafy green (design-system default; site overrides action color to `#4FB286`)

> Note: the palette deliberately reuses green (`#4FB286`) as the on-light action color and sky blue (`#BAD9F3`) as the on-dark accent. The `lavender`/`blush` token *names* are legacy; their *values* are the new blue/green.

### Typography
Four families, each with a fixed job (loaded via `tokens/fonts.css`):
- `var(--font-script)` **Petit Formal Script** — one emotional word only, never a sentence.
- `var(--font-display)` **Abril Fatface** — heavy poster moments (wordmark, big numbers). Never body/headlines.
- `var(--font-serif)` **Playfair Display** (700–900, plus italic) — serif headlines & script-style phrases.
- `var(--font-sans)` **DM Sans** (300 airy long-form, 600 labels) — all body, UI, eyebrows.
- Signature eyebrow: DM Sans ~10–11px, 600, `letter-spacing:.2–.3em`, uppercase, in green (on light) or sky blue (on dark).

### Spacing & layout
- Page card: `max-width:1180px; margin:0 auto; background:#fff; box-shadow:0 0 80px rgba(53,91,116,.08)`.
- Sticky nav: white, `padding:16px 40px`, `border-bottom:1px solid var(--gc-border)`, `position:sticky; top:0; z-index:100`.
- Section vertical padding: generous, roughly `clamp(48px,8vw,80px)`.
- Reading columns cap ~560–720px inside the card.

### Radius, borders, shadows
- Pills (buttons/badges): `border-radius:100px`.
- Cards: `6–16px` radius; event cards `6px` with `1px solid var(--gc-border)`.
- Shadows are cool/navy-tinted: `0 8px 26px rgba(53,91,116,.14)` (card hover), `0 0 80px rgba(53,91,116,.08)` (page card).

### Motion / hover
- Buttons rise `translateY(-2px)` on hover; short transitions (`.15–.2s`) on transform/color/background.
- Cards rise `translateY(-3px)` and deepen shadow on hover.
- Nav links shift to green on hover.
- Service rows shift background to `--gc-sage-light` on hover.
- No bounces, springs, or infinite loops.

## Screens / Views
Each page is a standalone `.dc.html`. Cross-page links use relative `href` (in the real build these become routes).

- **Home** (`Home.dc.html`) — sticky nav; cream brand strip (eyebrow "Greater Cincinnati · est. 2025" → serif "We believe in…" → muted sub-copy); split hero; "For women & community" block ("Find your people. Come sit at the table"); event cards linking to Events (e.g. "Girlhood Goes to Market", "Fall makers market · Cincinnati"); tool cards; newsletter block on navy; footer.
- **About** (`About.dc.html`) — navy story hero ("Our story" → "Uniting makers, teachers, leaders & learners"); values grid (numbered cards incl. "02 Community First — Community comes before the algorithm. Always.").
- **Events** (`Events.dc.html`) — event listing driven by a data array (id, month/day/year, category, badge colors, title, where, price, desc, long). Includes past-events gallery (image-slots) and upcoming events (Girlhood Goes to Market, Holiday Neighbors Market, New Year Intentions Brunch, etc.). All locations now read "· Cincinnati" or "Greater Cincinnati".
- **Newsletter** (`Newsletter.dc.html`) — navy hero, "A Voice That Carries", open-rate stat (52–66%), email capture.
- **Work With Me** (`Work With Me.dc.html`) — services/consulting offering.
- **Tools** (`Tools.dc.html`) — resource/tool cards.
- **UGC** (`UGC.dc.html`) — user-generated-content / community showcase ("Cincinnati rooted").
- **Partners** (`Partners.dc.html`) — community partners directory.
- **Consultation Intake** (`Consultation Intake.dc.html`) — intake form.
- **Worth Quiz** (`Worth Quiz.dc.html`) — interactive quiz.
- Archive/exploration variants (reference only, not the live pages): `Home v1.dc.html`, `Home Options.dc.html`, `Home Directions.dc.html`.

## Interactions & Behavior
- **Navigation:** sticky top nav; links route between pages. Nav links hover → green.
- **Buttons:** primary = green fill; secondary = navy fill; both pill-shaped, rise on hover.
- **Event cards:** hover raises shadow; clicking navigates to the Events page/detail.
- **Image slots** (Events gallery): drag-and-drop image placeholders in the prototype — in production these become CMS-managed images.
- **Forms** (Newsletter, Consultation Intake): standard capture/validation — wire to the real backend.
- **Worth Quiz:** stateful multi-step quiz — recreate state transitions in the target framework.

## State Management
- Mostly static/content pages — no global state beyond form inputs and the quiz.
- Newsletter/intake forms need controlled inputs + submit handling.
- Worth Quiz needs step index + collected answers state.

## Assets
- Cincinnati skyline + heart illustrations (watercolor blue and navy line versions) and the navy wordmark live in the design system's `assets/`. Use the brand's real assets in production.
- Icon language is intentionally light: emoji as category markers (Studio pages only, one per item) and Unicode glyphs (✓ ✦ — →). If a real icon set is needed, use Lucide at stroke ~1.75 in navy/slate and flag it to the brand.

## Files
Live pages (recreate these):
- `Home.dc.html`, `About.dc.html`, `Events.dc.html`, `Newsletter.dc.html`, `Work With Me.dc.html`, `Tools.dc.html`, `UGC.dc.html`, `Partners.dc.html`, `Consultation Intake.dc.html`, `Worth Quiz.dc.html`

Reference-only explorations:
- `Home v1.dc.html`, `Home Options.dc.html`, `Home Directions.dc.html`

Design-system source (tokens, fonts, shared components) is referenced from `_ds/girlhood-collective-design-system-.../` — use it to pull exact token values, but recreate components in your own stack.
